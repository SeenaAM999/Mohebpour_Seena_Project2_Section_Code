/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 *  Seena Mohebpour
 *  CIS-17C
 *  Snakes & Ladders 2.0
 *  Mon. Nov. 25, 2024
 */

// LIBRARIES
#include <iostream>
#include <map>
#include <set>
#include <list>
#include <queue>
#include <stack>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <string>
#include <sstream>
#include <unordered_set>
#include <unordered_map>

using namespace std;

// PROTOTYPE CLASSES
class Player;
class GameBoard;
class GamePlay;
class GameSetup;

// CLASSES
class Player {
private:
    string name;
    string color;
    string id;
    
    int position;
    int roll1, roll2;
    
    list<int> positionHistory;

public:
    Player(string);

    string getName();
    string getColor();
    string getID();
    
    int getPosition();
    int getRoll1();
    int getRoll2();
    
    void setID();
    void setColor(string);
    void setPosition(int);
    void displayPlayer();
    void rollDice();
    void addPositionHistory(int);
    void displayPositionHistory();
};

class GameBoard {
private:
    map<int, int> snakes;
    map<int, int> ladders;
    const int size = 100;

public:
    GameBoard();

    void displayBoard() const;
    void displaySnakesAndLadders() const;
    
    int getNewPosition(int) const;
    int checkSnakesOrLadders(int);
    
    const map<int, int>& getSnakes() const;
    const map<int, int>& getLadders() const;
};

class GamePlay {
private:
    Player* players[6];
    
    int numPlayers;
    int currentPlayerIndex;
    
    GameBoard board;
    
    queue<Player*> turnQueue;
    unordered_set<int> visitedPositions;
    stack<int> undoStack;


public:
    GamePlay(int, Player* []);
    
    void playTurn(int);
    void playGame();
    void printCurrentTurn();
    void displayPodium();
    void undoLastMove();
    
    bool checkGameOver();
};

class GameSetup {
private:
    int numPlayers;
    
    Player** players;
    
public:
    GameSetup(int);
    
    void setupPlayers();
    
    Player** getPlayers();
};

// PROTOTYPE FUNCTIONS
void displayRules();
void explainBoard();

// MAIN PROGRAM
int main() {
    GameBoard board;
    
    int numPlayers;
    int menuChoice;
    
    cout << "Welcome to Snakes & Ladders!" << endl;
    
    do {
        cout << endl << "--- Main Menu ---" << endl;
        cout << "1) Explain the Rules" << endl;
        cout << "2) Display the Board" << endl;
        cout << "3) Play the Game" << endl;
        cout << "Enter your choice: ";
        cin >> menuChoice;

        switch (menuChoice) {
            case 1:
                displayRules();
                break;
            case 2:
                explainBoard();               
                board.displayBoard();
                board.displaySnakesAndLadders();
                break;
            case 3:
                cout << endl << "Starting the game..." << endl;
                break;
            default:
                cout << "Invalid choice! Please select 1, 2, or 3." << endl;
        }
    } while (menuChoice != 3);


    // Player setup (same as before)
    cout << endl << "Enter number of players (2-6): ";
    cin >> numPlayers;

    cout << endl;
    
    GameSetup gameSetup(numPlayers);
    gameSetup.setupPlayers();

    Player** players = gameSetup.getPlayers();

    // GamePlay setup and start
    GamePlay game(numPlayers, players);
    game.playGame();
    
    return 0;
}

// FUNCTIONS (CLASSES INCLUDED)
GameBoard::GameBoard() {
    // Define snakes
    snakes[16] = 6;
    snakes[47] = 26;
    snakes[49] = 11;
    snakes[56] = 53;
    snakes[62] = 19;
    snakes[64] = 60;
    snakes[87] = 24;
    snakes[93] = 73;
    snakes[95] = 75;
    snakes[98] = 78;

    // Define ladders
    ladders[1] = 38;
    ladders[4] = 14;
    ladders[9] = 31;
    ladders[21] = 42;
    ladders[28] = 84;
    ladders[36] = 44;
    ladders[49] = 57;
    ladders[51] = 67;
    ladders[71] = 91;
    ladders[80] = 100;
}

void GameBoard::displayBoard() const {
    cout << endl << "Snakes & Ladders Board:" << endl;
    cout << "+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+" << endl;

    for (int row = 10; row > 0; --row) {
        for (int col = 1; col <= 10; ++col) {
            int position = (row % 2 == 0) ? ((row - 1) * 10 + col) : (row * 10 - col + 1);
            cout << "| " << setw(3) << position << " ";
        }
        cout << "|" << endl;
        cout << "+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+" << endl;
    }
}

// Display snakes and ladders in tabular format
void GameBoard::displaySnakesAndLadders() const {
    cout << endl << "Snakes & Ladders Locations: " << endl;
    cout << "+-----------------+-----------------+" << endl;
    cout << "| Ladders         | Snakes          |" << endl;
    cout << "+--------+--------+--------+--------+" << endl;
    cout << "| From   | To     | From   | To     |" << endl;
    cout << "+--------+--------+--------+--------+" << endl;

    int ladderKeys[10] = {1, 4, 9, 21, 28, 36, 49, 51, 71, 80};
    int snakeKeys[10] = {16, 47, 49, 56, 62, 64, 87, 93, 95, 98};

    for (int i = 0; i < 10; ++i) {
        // Ladders
        if (i < 10 && ladders.count(ladderKeys[i]) > 0) {
            cout << "| " << setw(4) << ladderKeys[i] << "   | " 
                 << setw(4) << ladders.find(ladderKeys[i])->second;
        } else if (i < 10) {
            cout << "| " << setw(8) << " " << " | " 
                 << setw(8) << " ";
        }

        // Snakes
        if (snakes.count(snakeKeys[i]) > 0) {
            cout << "   | " << setw(4) << snakeKeys[i] << "   | " 
                 << setw(4) << snakes.find(snakeKeys[i])->second << "   |" << endl;
        } else {
            cout << " | " << setw(6) << " " << " | " 
                 << setw(5) << " " << "   |" << endl;
        }
    }
    
    cout << "+--------+--------+--------+--------+" << endl;
}

// Get the new position of a player after encountering a snake or ladder
int GameBoard::getNewPosition(int position) const {
    if (snakes.count(position)) {
        return snakes.find(position)->second;
    }
    
    if (ladders.count(position)) {
        return ladders.find(position)->second;
    }
    
    return position;
}

// Accessor for testing
const map<int, int>& GameBoard::getSnakes() const {
    return snakes;
}

const map<int, int>& GameBoard::getLadders() const {
    return ladders;
}

int GameBoard::checkSnakesOrLadders(int position) {
    if (snakes.find(position) != snakes.end()) {
        return snakes[position];
    }
    
    if (ladders.find(position) != ladders.end()) {
        return ladders[position];
    }
    
    return position;
}

GamePlay::GamePlay(int numPlayers, Player* players[]) {
    this->numPlayers = numPlayers;
    this->currentPlayerIndex = 0;

    for (int i = 0; i < numPlayers; i++) {
        this->players[i] = players[i];
        turnQueue.push(players[i]);
    }
}

void GamePlay::playTurn(int currentPlayerIndex) {
    if (checkGameOver()) {
        displayPodium();
        return; // Exit the recursion if the game is over
    }

    Player* currentPlayer = players[currentPlayerIndex];
    
    int choice;
    do {
        cout << endl << currentPlayer->getID() << "'s Turn to Play." << endl;
        cout << "1) Roll the Dice." << endl;
        cout << "2) Quit Game." << endl;
        cout << "3) Undo Last Move." << endl;
        cout << "Enter your choice: ";
        cin >> choice;
        
        if (choice == 2) {
            cout << currentPlayer->getID() << " has chosen to quit the game." << endl;
            exit(0);
        } else if (choice == 1) {
            currentPlayer->rollDice();
            printCurrentTurn();
            
            int initialPosition = currentPlayer->getPosition();
            int newPosition = board.checkSnakesOrLadders(initialPosition);
            
            if (newPosition != initialPosition) {
                if (newPosition > initialPosition) {
                    cout << currentPlayer->getID() << " landed on a ladder." << endl;
                    cout << currentPlayer->getID() << " moved up to space " << newPosition << "." << endl;
                } else {
                    cout << currentPlayer->getID() << " landed on a snake." << endl;
                    cout << currentPlayer->getID() << " moved down to space " << newPosition << "." << endl;
                }
            }
            
            currentPlayer->addPositionHistory(newPosition);
            
            if (newPosition == 100) {
                cout << currentPlayer->getName() << " wins the game!" << endl;
                return; // End recursion if someone wins
            }

            // Add the player's new position to visited positions (hashing)
            visitedPositions.insert(newPosition);
            
            break;
        } else if (choice == 3) {
            undoLastMove();
        } else {
            cout << "Invalid choice. Please select again." << endl;
        }
        
    } while (true);

    // Move to the next player using recursion
    currentPlayerIndex = (currentPlayerIndex + 1) % numPlayers;
    playTurn(currentPlayerIndex); // Recursive call for the next player
}

void GamePlay::undoLastMove() {
    if (undoStack.empty()) {
        cout << "No moves to undo." << endl;
    } else {
        int lastMove = undoStack.top();
        undoStack.pop();
        cout << "Undoing last move. Returning to position " << lastMove << "." << endl;
    }
}

void GamePlay::printCurrentTurn() {
    Player* currentPlayer = players[currentPlayerIndex];
    cout << currentPlayer->getID() << " rolled a " 
         << currentPlayer->getRoll1() << " and " 
         << currentPlayer->getRoll2() << "." << endl;
    cout << currentPlayer->getID() << " lands on space " 
         << currentPlayer->getPosition() << "." << endl;
    cout << endl;
}

bool GamePlay::checkGameOver() {
    for (int i = 0; i < numPlayers; i++) {
        if (players[i]->getPosition() == 100) {
            return true;  // A player reached space 100
        }
    }
    return false;
}

void GamePlay::displayPodium() {
    if (numPlayers == 2) {
        Player* first = players[0];
        Player* second = players[1];
        
        if (first->getPosition() < second->getPosition()) {
            swap(first, second);
        }

        cout << endl << "--- Podium ---" << endl;
        cout << "1st: " << first->getName() << endl;
        cout << "2nd: " << second->getName() << endl;
        
    } else if (numPlayers >= 3) {
        Player* first = players[0];
        Player* second = players[1];
        Player* third = players[2];

        for (int i = 1; i < numPlayers; ++i) {
            if (players[i]->getPosition() > first->getPosition()) {
                third = second;
                second = first;
                first = players[i];
            } else if (players[i]->getPosition() > second->getPosition()) {
                third = second;
                second = players[i];
            } else if (players[i]->getPosition() > third->getPosition()) {
                third = players[i];
            }
        }

        cout << endl << "--- Podium ---" << endl;
        cout << "1st: " << first->getName() << endl;
        cout << "2nd: " << second->getName() << endl;
        cout << "3rd: " << third->getName() << endl;
    }
}

void GamePlay::playGame() {
    while (!checkGameOver()) {
        playTurn(currentPlayerIndex);
    }
    
    displayPodium();
}

GameSetup::GameSetup(int numPlayers) {
    this->numPlayers = numPlayers;
    this->players = new Player*[numPlayers];
}

void GameSetup::setupPlayers() {
    string availableColors[] = {"Red", "Blue", "Purple", "Green", "Black", "White"};
    bool colorTaken[] = {false, false, false, false, false, false};
    
    for (int i = 0; i < numPlayers; i++) {
        string playerName;
        string color;
        
        // Get player name
        cout << "Enter name for Player " << (i + 1) << ": ";
        cin >> playerName;
        
        // Get unique color for the player
        bool validColor = false;
        while (!validColor) {
            cout << "Enter color for Player " << (i + 1) << " (Red, Blue, Purple, Green, Black, White): ";
            cin >> color;
            
            cout << endl;
            
            for (int j = 0; j < 6; j++) {
                if (color == availableColors[j] && !colorTaken[j]) {
                    colorTaken[j] = true; // Mark color as taken
                    validColor = true;
                    break;
                }
            }
            
            if (!validColor) {
                cout << "Invalid color or color already taken. Please choose another color." << endl;
                cout << endl;
            }
        }

        // Create player with the provided name and color
        players[i] = new Player(playerName);
        players[i]->setColor(color); // Assuming Player class has a setColor function
    }
}

Player** GameSetup::getPlayers() {
    return players;
}

Player::Player(string name) {
    this->name = name;
    this->color = "";
    this->position = 0;
    this->id = "";
    this->roll1 = 0;
    this->roll2 = 0;
}

string Player::getName() {
    return name;
}

string Player::getColor() {
    return color;
}

string Player::getID() {
    return id;
}

int Player::getPosition() {
    return position;
}

int Player::getRoll1() {
    return roll1;
}

int Player::getRoll2() {
    return roll2;
}

void Player::setPosition(int pos) {
    position = pos;
}

void Player::setColor(string color) {
    this->color = color;
    setID();
}

void Player::setID() {
    if (!name.empty() && !color.empty()) {
        stringstream ss;
        ss << name[0] << "." << color[0]; 
        this->id = ss.str();
    }
}

void Player::displayPlayer() {
    cout << "Name: " << name << endl;
    cout << "Color: " << color << endl;
    cout << "ID: " << id << endl;
    cout << "Position: " << position << endl;
}

void Player::rollDice() {
    roll1 = rand() % 6 + 1;
    roll2 = rand() % 6 + 1;
    int totalCount = roll1 + roll2;
    position += totalCount;
    
    if (position > 100) {
        position = 100;
    }
}

void Player::addPositionHistory(int pos) {
    positionHistory.push_back(pos); 
}

void Player::displayPositionHistory() {
    for (int pos : positionHistory) {
        cout << pos << " ";
    }
    cout << endl;
}

// Function to display the rules
void displayRules() {
    cout << endl << "--- Rules of the Game ---" << endl;
    cout << "The game is played on a 100-space board." << endl;
    cout << "Players take turns rolling two dice." << endl;
    cout << "Players move forward by the sum of the dice roll." << endl;
    cout << "If a player lands on a snake, they move down to a lower space." << endl;
    cout << "If a player lands on a ladder, they move up to a higher space." << endl;
    cout << "The first player to reach space 100 wins the game." << endl;
    cout << "If a player rolls doubles, they get another turn." << endl;
    cout << "Players can quit at any time by choosing to quit during their turn." << endl;
    cout << endl;
}

// Function to display the board
void explainBoard() {
    cout << endl << "--- Snakes and Ladders Board ---" << endl;
    cout << "This is a standard 10x10 board with spaces numbered from 1 to 100." << endl;
    cout << "Snakes will pull you down, and ladders will lift you up!" << endl;
    cout << endl;
}
